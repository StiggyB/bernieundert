package trees;

import java.util.ArrayDeque;
import java.util.Queue;

public class BinarySearchTree<E extends Comparable<E>> implements IBinarySearchTree<E> {
	E key;
	BinarySearchTree<E> left, right;
	
	public BinarySearchTree() {
		this.key=null;
		this.left=null;
		this.right=null;
	}

	@Override
	public E findMin() {
		if (this.isEmpty()) {
			return null;
		}
		if (this.left.isEmpty()) {
			return this.key;
		}
		return this.left.findMin();
	}

	@Override
	public E findMax() {
		if (this.isEmpty()) {
			return null;
		}
		if (this.right.isEmpty()) {
			return this.key;
		}
		return this.right.findMax();
	}

	@Override
	public int getNodeCount() {
		if (this.isEmpty()) {
			return 0;
		}
		return 1 + left.getNodeCount() + right.getNodeCount();
	}

	@Override
	public boolean isEmpty() {
		return this.key==null;
	}

	@Override
	public boolean isLeaf() {
		return left==null && right==null;
	}

	@Override
	public int getHeight() {
		if (this.isEmpty()) {
			return 0;
		}
		return Math.max(left.getHeight(), right.getHeight()) + 1;
	}

	@Override
	public String preOrderTraverse() {
		if (this.isEmpty()) {
			return "";
		}
		else {
			return key + " " + left.preOrderTraverse() +  right.preOrderTraverse();
		}
	}

	@Override
	public String postOrderTraverse() {
		if (this.isEmpty()) {
			return "";
		}
		else {
			return left.postOrderTraverse() + right.postOrderTraverse() + key + " ";
		}
	}

	@Override
	public String levelOrderTraverse() {
		String s="";
		Queue<BinarySearchTree<E>> q =new ArrayDeque<BinarySearchTree<E>>();
		q.add(this);
		while (!q.isEmpty()) {
			BinarySearchTree<E> t = q.remove();
			s+=t.key + " ";
			if (!t.left.isEmpty())
				q.add(t.left);
			if (!t.right.isEmpty())
				q.add(t.right);
		}
		return s;
	}
	

	@Override
	public boolean addKey(E key) {
		if (this.isEmpty()) {
			this.key=key;
			this.left =new BinarySearchTree<E>();
			this.right=new BinarySearchTree<E>();
			return true;
		}
		int compareresult=key.compareTo(this.key);
		if (compareresult==0) {
			return false;
		}
		if (compareresult<0) {
			return this.left.addKey(key);
		}
		else {
			return this.right.addKey(key);
		}
	}

	@Override
	public boolean deleteKey(E key) {
		if (this.isEmpty()) {
			return false;
		}
		int compareresult=key.compareTo(this.key);
		if (compareresult<0) {
			return this.left.deleteKey(key);
		}
		if (compareresult>0) {
			return this.right.deleteKey(key);
		}
		else { 
			if(left.isEmpty() && right.isEmpty()) {
				this.key = null;
				this.left = null;
				this.right = null;
				return true;
			}
			if(!left.isEmpty() && right.isEmpty()) {
				this.key = this.left.key;
				this.right = this.left.right;
				this.left = this.left.left;
				return true;
			}
			if(left.isEmpty() && !right.isEmpty()) {
				this.key = this.right.key;
				this.left = this.right.left;
				this.right = this.right.right;
				return true;
			}
			else {
				E minKey=this.right.findMin();
				this.key = minKey;
				return this.right.deleteKey(minKey);

			}
		}
		
	}

	@Override
	public boolean find(E key) {
		if (this.isEmpty()) {
			return false;
		}
		int compareresult=key.compareTo(this.key);
		if (compareresult==0) {
			return true;
		}
		if (compareresult<0) {
			return this.left.find(key);
		}
		else {
			return this.right.find(key);
		}
	}

	@Override
	public String inOrderTraverse() {
		if (this.isEmpty()) {
			return "";
		}
		else {
			return left.inOrderTraverse() + key + " " + right.inOrderTraverse();
		}
	}
	
	
	public String toString(){
		if (this.isEmpty()) {
			return "()";
		}
		else {
			String s="(";
			if (!left.isEmpty()){
				s+=left.toString();
			}
			s+=key;
			if (!right.isEmpty()){
				s+=right.toString();
			}
			s+=")";
			return s;
		}
	}

}
